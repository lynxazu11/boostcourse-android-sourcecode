package org.techtown.myfragment;

/**
 *
 */

public interface FragmentCallback {

    public void onCommand(String command, String data);

}
