package org.techtown.myvolley;

import android.graphics.Movie;

import java.util.ArrayList;

/**
 *
 */

public class MovieListResult {

    String boxofficeType;
    String showRange;

    ArrayList<Movie> dailyBoxOfficeList = new ArrayList<Movie>();

}
