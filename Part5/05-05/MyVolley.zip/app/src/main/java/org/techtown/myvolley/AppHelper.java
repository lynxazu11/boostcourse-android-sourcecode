package org.techtown.myvolley;

import com.android.volley.RequestQueue;

/**
 *
 */

public class AppHelper {

    public static RequestQueue requestQueue;



}
