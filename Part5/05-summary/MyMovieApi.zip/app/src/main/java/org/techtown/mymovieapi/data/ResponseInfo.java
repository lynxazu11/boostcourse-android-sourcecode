package org.techtown.mymovieapi.data;

/**
 message: "movie readMovieList 성공",
 code: 200,
 resultType: "list",
 result
 */

public class ResponseInfo {

    public String message;
    public int code;
    public String resultType;

}
