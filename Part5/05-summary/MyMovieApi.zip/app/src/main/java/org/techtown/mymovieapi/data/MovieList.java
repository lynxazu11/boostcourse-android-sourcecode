package org.techtown.mymovieapi.data;

import java.util.ArrayList;

/**
 *
 */

public class MovieList {

    public ArrayList<MovieInfo> result = new ArrayList<MovieInfo>();

}
