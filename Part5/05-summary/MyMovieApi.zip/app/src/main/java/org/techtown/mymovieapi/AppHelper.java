package org.techtown.mymovieapi;

import com.android.volley.RequestQueue;

/**
 *
 */

public class AppHelper {

    public static RequestQueue requestQueue;

    public static String host = "boostcourse-appapi.connect.or.kr";
    public static int port = 10000;

}
